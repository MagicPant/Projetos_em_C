#include <math.h>
#include <stdlib.h>
#include <stdio.h>
#include <locale.h>
#include <string.h>

/* run this program using the console pauser or add your own getch, system("pause") or input loop */

int main() {
	setlocale(LC_ALL,"");
	int qtdLinha,qtdColuna;
	printf("\nDigite o numero de linhas da matriz : \n\n");
	scanf("%d", &qtdLinha);
	printf("\nDigite o numero de colunas da matriz : \n\n");
	scanf("%d", &qtdColuna);
	int matriz [qtdLinha][qtdColuna];
	//linha
	for(int i=0;i<qtdLinha;i++){
		//coluna
		for(int j=0;j<qtdColuna;j++){
			printf("\nElemento [%d][%d]= ",i,j);
			scanf("%d", &matriz[i][j]);
		}
	}
	for(int i=0;i<qtdLinha;i++){
		printf("\n");
		for(int j=0; j<qtdColuna; j++){
		printf("[%d]",matriz[i][j]);
		}
	}
}


#include <math.h>
#include <stdlib.h>
#include <stdio.h>
#include <locale.h>
#include <string.h>

/* run this program using the console pauser or add your own getch, system("pause") or input loop */

int main() {
	setlocale(LC_ALL,"");
	int matriz [3][3];
	//linha
	for(int i=0;i<3;i++){
		//coluna
		for(int j=0;j<3;j++){
			printf("\nElemento [%d][%d]= ",i,j);
			scanf("%d", &matriz[i][j]);
		}
	}
	int m = matriz[2][0];
	printf("%d", m);
		
	//multiplicar m por cada linha e coluna
	for(int i=0;i<3;i++){
		printf("\n");
		for(int j=0; j<3; j++){
			int matrix = matriz[i][j]*m;
			printf("[%d]",matrix);
		}
	}
}

#include <math.h>
#include <stdlib.h>
#include <stdio.h>
#include <locale.h>
#include <string.h>

/* run this program using the console pauser or add your own getch, system("pause") or input loop */

int main() {
	setlocale(LC_ALL,"");
	int matriz [5][5];
	int m,n;
	
	printf("digite um numero: ");
	scanf("%d", &m);
	
	//linha
	for(int i=0;i<5;i++){
		//coluna
		for(int j=0;j<5;j++){
			printf("\nElemento [%d][%d]= ",i,j);
			scanf("%d", &matriz[i][j]);
		}
	}

	for(int i=0;i<5;i++){
		printf("\n");
		for(int j=0; j<5; j++){
			if(matriz[i][j]==m){
				printf("\n %d na posicao [%d][%d]",matriz[i][j],i,j);
			}else{
				n=1;
			}
		}
	}
	if(n==1){
		printf("nenhum valor encontrado");
	}
}

	

#include <stdlib.h>
#include <stdio.h>
#include <string.h>

/* run this program using the console pauser or add your own getch, system("pause") or input loop */

int main() {
	char nome[5][20]; //5 espa�os para armazenar texto; 20 limite de espa�o da variavel(20 caracteres)
	for(int x=0;x<3;x++){
		printf("\n%d Digite o nome: ", x);
		gets(nome[x]);
	}
	for(int i=0;i<3;i++){
		printf("\n %d - %s -%d ",i , nome[i] ,strlen(nome[i]) );
	}
	
}

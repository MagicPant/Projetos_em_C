#include <stdlib.h>
#include <stdio.h>
#include <string.h>

/* run this program using the console pauser or add your own getch, system("pause") or input loop */

int main() {
	int conta=0,conte=0,conti=0,conto=0,contu=0,tam=0;
	char nome[3][30];
	for(int x=0;x<3;x++){
		printf("\nDigite o nome: ");
		gets(nome[x]);
	}
	for(int i=0; i<3;i++){
		tam=strlen(nome[i]);
		for(int m=0;m<tam;m++){
		if(nome[i][m]=='A'||nome[i][m]=='a')
		conta++;
		nome[i][m]='A';	
		if(nome[i][m]=='E'||nome[i][m]=='e')
		conte++;
		nome[i][m]='E';	
		if(nome[i][m]=='I'||nome[i][m]=='I')
		conti++;
		nome[i][m]='I';		
		if(nome[i][m]=='O'||nome[i][m]=='o')
		conto++;
		nome[i][m]='O';			
		if(nome[i][m]=='U'||nome[i][m]=='u')
		contu++;
		nome[i][m]='U';			
		}
		printf("\n\nNos nomes digitados tem %d Letras A",conta);
		printf("\n\nNos nomes digitados tem %d letras E",conte);
		printf("\n\nNos nomes digitados tem %d letras I",conti);
		printf("\n\nNos nomes digitados tem %d letras O",conto);
		printf("\n\nNos nomes digitados tem %d letras U",contu);
		for(int i=0;i>3;i++){
			printf("\n%d-%s",i,nome[i]);
		}
		
	}
	
}

#include <stdlib.h>
#include <stdio.h>
#include <string.h>

/* run this program using the console pauser or add your own getch, system("pause") or input loop */

int main() {
	int conta=0,conte=0,tam=0;
	char nome[3][30];
	for(int x=0;x<3;x++){
		printf("\nDigite o nome: ");
		gets(nome[x]);
	}
	for(int i=0; i<3;i++){
		tam=strlen(nome[i]);
		for(int m=0;m<tam;m++){
			if(nome[i][m]=='A'||nome[i][m]=='a')
				conta++;
				if(nome[i][m]=='E'||nome[i][m]=='e')
				conte++;			
		}
		printf("\n\nNos nomes digitados tem %d Letras A",conta);
		printf("\n\nNos nomes digitados tem %d letras E",conte);
		
	}
	
}

#include <stdio.h>
#include <stdlib.h>

/* run this program using the console pauser or add your own getch, system("pause") or input loop */

int main() {
	int controle = 0;
	do{
		printf("os numeros at� 200 divisiveis por 4 sao : ");
		for(int i=0;i<200;i++){
			if(i%4==0){
				printf("%d \n", i);
			}
		}
		printf("digite 0 se quer continuar e 1 se quiser sair: \n");
		scanf("%d", &controle);
	}while(controle==0);
	
}

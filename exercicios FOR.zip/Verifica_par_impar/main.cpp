#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>

/* run this program using the console pauser or add your own getch, system("pause") or input loop */

int main() {
    int sair = 0 ;
    do{
    int num;
	printf ("Digite um numero: ");
	scanf ("%i", &num);
if(num%2==0){
	printf("%i - eh par \n", num);			
	}
else if(num%2==1){
	printf("%i - eh impar \n",num);
	}
	printf("digite 1 se quiser sair e 0 se quiser repetir \n");
	scanf("%i", &sair);
} 
while (sair==0);

}
	


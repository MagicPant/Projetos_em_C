#include <iostream>

/* run this program using the console pauser or add your own getch, system("pause") or input loop */

int main() {
	
	int num,media,quantidade,soma,controle;	
	do{
	system("cls");
	soma=0;
	printf("quantos numeros voce quer colocar na media: ");
	scanf("%d", &quantidade);
	for(int i=1;i<quantidade+1;i++){
		printf("%d -", i);
		scanf("%d", &num);
		soma += num;
	}	
	media = soma/quantidade;
	printf("a soma eh: %d \n", soma );
	printf("a media eh: %d \n", media );
	scanf("%d", &controle);
	}while(controle==1);
}
	
	

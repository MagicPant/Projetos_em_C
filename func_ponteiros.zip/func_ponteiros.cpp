/*4.    Problemas / Tarefas
4.1  Elabore uma ou mais funções que receba a nota de 3 provas (n1, n2 e n3),
 calcule e retorne:
a)    média aritmética simples (n1 + n2 + n3) / 3
b)    a média ponderada ((n1 * 2) + (n2 * 3) + (n3 * 5)) / 10
4.2  Elabore uma ou mais funções que recebe dois números inteiros como parâmetro (n1 e    n2) e retorne:
a) a soma dos números;
b) a multiplicação dos números.
Observação: Para os 2 problemas propostos (4.1 e 4.2), elaborar soluções:
A.  Utilizando funções com passagem de parâmetros por valor;
B.  Utilizando funções com  atualização de variáveis globais; e
C.  Utilizando funções com passagem de parâmetros por referência com uso de ponteiros.


AQUI 4.3  Refatore (refaça) a solução proposta para o item 4.2 fazendo a chamada das funções (soma e multiplicação) através do uso de ponteiros  (para o código das funções e não para os parâmetros).
*/
#include<stdlib.h>
#include<stdio.h>
#include<math.h>
float a1,a2,a3;
float glob;
int t1,t2;
//funções para realizar operações por referencia de valor e atualizar variaveis globais:
float mediaSimples(float n1,float n2,float n3){
    return (n1+n2+n3)/3;
}
float mediaPonderada(float n1,float n2,float n3){
    return ((n1*2)+(n2*3)+(n3*5))/10;
}

int soma(int n1,int n2){
    return (n1+n2);
}

int multiplicacao(int n1,int n2){
    return (n1*n2);
}

//funções para realizar operações com ponteiro
float mediaSimplesPont(float *n1,float *n2,float *n3){
    return(*n1+*n2+*n3)/3;
}

float mediaPondPont(float *n1,float *n2,float *n3){
    return((*n1*2)+(*n2*3)+(*n3*5))/10;
}

int somaPont(int *n1,int *n2){
    return(*n1+*n2);
}

int multiplicacaoPont(int *n1,int *n2){
    return((*n1)*(*n2));
}


int main(void){
    int escolha,s1,s2;
    float b1,b2,b3;
    float val,pont=0;
    int (*p) (int n1,int n2);
    pergunta:
    printf("\nDigite a operacao desejada:\n1-media simples\n2-media ponderada\n3-soma\n4-multiplicacao: \n");
    scanf("%d",&escolha);
    switch (escolha){
    case 1:
        //passagem por valor
        printf("\nCom passagem de valor: ");
        printf("\nDigite n1:");
        scanf("%f",&b1);
        printf("\nDigite n2:");
        scanf("%f",&b2);
        printf("\nDigite n3:");
        scanf("%f",&b3);
        val = mediaSimples(b1,b2,b3);
        printf("\nmedia: %.1f",val);
        //variaveis globais
        printf("\nCom variaveis globais: ");
        printf("\nDigite n1:");
        scanf("%f",&a1);
        printf("\nDigite n2:");
        scanf("%f",&a2);
        printf("\nDigite n3: ");
        scanf("%f",&a3);
        glob = mediaSimples(a1,a2,a3);
        printf("\nmedia: %.1f",glob);
        //pont
        printf("\n\ncom ponteiro usando os valores ja declarados na passagem de valor:");
        pont = mediaSimplesPont(&b1,&b2,&b3);
        printf("\n\nponteiro da media simples: [%.1f] ",pont);
        break;
    case 2:
        //passagem por valor
        printf("\nCom passagem de valor: ");
        printf("\nDigite n1:");
        scanf("%f",&b1);
        printf("\nDigite n2:");
        scanf("%f",&b2);
        printf("\nDigite n3:");
        scanf("%f",&b3);
        val = mediaPonderada(b1,b2,b3);
        printf("\nmedia: %.1f",val);
        //variaveis globais
        printf("\nCom variaveis globais: ");
        printf("\nDigite n1:");
        scanf("%f",&a1);
        printf("\nDigite n2:");
        scanf("%f",&a2);
        printf("\nDigite n3:");
        scanf("%f",&a3);
        glob=mediaPonderada(a1,a2,a3);
        printf("\nmedia: %.1f",glob);
        //ponteiros
        printf("\n\ncom ponteiro usando os valores ja declarados na passagem de valor:");
        pont = mediaPondPont(&b1,&b2,&b3);
        printf("\n\nponteiro da media simples: [%.1f] ",pont);
        break;
    case 3:
        //passagem por valor
        printf("\nCom passagem de valor: ");
        printf("\nDigite n1:");
        scanf("%d",&s1);
        printf("\nDigite n2:");
        scanf("%d",&s2);
        val=soma(s1,s2);
        printf("\nsoma: %.1f",val);
        //variaveis globais
        printf("\nCom variaveis globais: ");
        printf("\nDigite n1:");
        scanf("%d",&t1);
        printf("\nDigite n2:");
        scanf("%d",&t2);
        glob = soma(t1,t2);
        printf("\nsoma: %.1f",glob);
        //ponteiros
        printf("\n\ncom ponteiro usando os valores ja declarados na passagem de valor:");
        pont = somaPont(&s1,&s2);
        printf("\n\nponteiro da soma: [%.1f] ",pont);
        //ponteiro para funcao
        p = soma;
        printf("\n\nfuncao chamada por ponteiro: %d",p(s1,s2));
        break;
    case 4:
        //passagem por valor
        printf("\nCom passagem de valor: ");
        printf("\nDigite n1:");
        scanf("%d",&s1);
        printf("\nDigite n2:");
        scanf("%d",&s2);
        val=multiplicacao(s1,s2);
        printf("\nmultiplicacao: %.1f",val);
        //variaveis globais
        printf("\nCom variaveis globais: ");
        printf("\nDigite n1:");
        scanf("%d",&t1);
        printf("\nDigite n2:");
        scanf("%d",&t2);
        glob = multiplicacao(t1,t2);
        printf("\nmultiplicacao: %.1f",glob);
        //ponteiros
        printf("\n\ncom ponteiro usando os valores ja declarados na passagem de valor:");
        pont = multiplicacaoPont(&s1,&s2);
        printf("\n\nponteiro da multiplicacao: [%.1f] ",pont);
        //ponteiro para funcao
        p = multiplicacao;
        printf("\n\nfuncao chamada por ponteiro: %d",p(s1,s2));
        break;
    default:
        goto pergunta;
    }
    printf("\n\n");
}

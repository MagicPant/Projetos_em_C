#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

/* Armazenar em Vetores, Nomes e Notas PR1 e PR2 de 6 alunos. Calcular a m�dia de cada aluno
e imprimir aprovado se a m�dia for maior que 5 e reprovado se m�dia for menor ou igual a 5.
OBS.: 2 vetores para as notas tipo float. 1 vetor para os nomes. 1 vetor para a m�dia. 1 vetor
para situa��o.
*/

int main() {
int opcao;
float media[6],nota1[6],nota2[6];
char nome[6][30], situacao[6][15],nome2[6][30];
for(int i=0;i<6;i++){
	
	printf("informe o nome %d ",i);
	gets(nome[i]);
	
	printf("informe a nota da prova 1 do aluno %s ", nome[i] );
	scanf("%f", &nota1[i]);
	
	printf("informe a nota da prova 2 do aluno %s ", nome[i] );
	scanf("%f", &nota2[i]);
	
	fflush(stdin);
	system("cls");

	media[i]= (nota1[i] +nota2[i])/2;
	
	if(media[i] > 5)
		strcpy(situacao[i],"Aprovado");
	else
		strcpy(situacao[i],"Reprovado");	
 }
	
	printf("deseja listar os alunos ou sair do programa?\n 1-listar\n2-sair:\n");
	scanf("%d", &opcao);
	if (opcao ==2){
		exit(0);
	}else if(opcao ==1){
			printf("\n_________________________________________");
			printf("\nNome\tNota1\tNota2\tMedia\tSituacao");
			printf("\n__________________________________________");
		for(int x=0;x<6;x++){
			printf("\n%s\t%0.2f\t%0.2f\t%0.2f\t%s",nome[x],nota1[x],nota2[x],media[x],situacao[x]);
			printf("\n__________________________________________");			
		}	
	}
	printf("\n\n");
	system("pause");
}


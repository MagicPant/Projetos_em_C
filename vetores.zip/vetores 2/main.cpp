#include <stdio.h>
#include <stdlib.h>
/* run this program using the console pauser or add your own getch, system("pause") or input loop */

int main() {
	int num[50],vet,achei=0;
	for(int x=1;x<8;x++){
		printf("DIGITE UM NUMERO PARA A POSICAO %d: ", x);
		scanf("%d", &num[x]);
	}
	//system("cls");
	printf("DIGITE UM NUMERO A SER PESQUISADO: ");
	scanf("%d", &vet);
	for(int x=1;x<8;x++){
		if(num[x]==vet){
			printf("ECXISTE no vetor \n posicao = %d\n valor = %d \n",x,num[x]);
			achei=1;
		}		
	}
if(achei==0){
		printf("NON ECXISTE \n");
	}
	
	
}

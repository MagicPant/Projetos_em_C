#include <stdio.h>
#include <stdlib.h>
/* run this program using the console pauser or add your own getch, system("pause") or input loop */

int main() {
	int nume;//normal
	int num[5];//vetor
	printf("DIGITE UM NUMERO: \n");
	scanf("%i", &nume);
	for(int x=0; x<5; x++ ){
		printf("INSIRA UM NUMERO NA POSICAO %d \n", x);
		scanf("%d", &num[x]);
	}
	for(int i =0;i<5;i++){
		printf("\n a posicao %d do vetor eh %d", i,num[i]);
	}
}
